/**
 * 
 */
/**
 * 
 */
module AuditManagementSystem {
	requires java.desktop;
}